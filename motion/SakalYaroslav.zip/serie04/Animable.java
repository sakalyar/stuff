package motion.view;

public interface Animable {

    // COMMANDE

    /**
     * Anime le composant graphique une fois.
     */
    void animate();
}

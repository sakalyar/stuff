
typedef enum type_synth {
	NUM, BOOL, ERR_O, ERR_T
	
} t_synth;
